% Main OptiTrack interface
% Settings
%WPT_FILENAME = 'C:\Users\StarL\Documents\Workspace\starl\trunk\android\LightPaintNew\waypoints\pacman.wpt';
%WPT_FILENAME = 'C:\Users\StarL\Documents\Workspace\starl\trunk\android\LightPaintNew\waypoints\cube2.wpt';
WPT_FILENAME = 'C:\Users\StarL\Documents\Workspace\starl\trunk\matlab\matlab_optitrack_3d\waypoints\simpleTest.wpt';

load_settings;
mainprog;
    
