track_shutdown
clear
clc
quit