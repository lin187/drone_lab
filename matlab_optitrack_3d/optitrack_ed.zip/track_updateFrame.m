function track_updateFrame()
calllib('NPTrackingTools', 'TT_UpdateSingleFrame');