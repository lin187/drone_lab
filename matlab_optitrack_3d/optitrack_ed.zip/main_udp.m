% Main OptiTrack interface
% Settings
%WPT_FILENAME = 'C:\Users\StarL\Documents\Workspace\starl\trunk\android\LightPaintNew\waypoints\pacman.wpt';
WPT_FILENAME = 'C:\Users\StarL\Documents\Workspace\starl\trunk\android\LightPaintNew\waypoints\cube2.wpt';
load_settings;
mainprog;
    
